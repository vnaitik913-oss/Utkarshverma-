UTKARSH VERMA — WEBSITE DRAFT

Contents:
- index.html: responsive personal portfolio
- images/: four gently enhanced copies of the photos you supplied

Preview:
Open index.html in a browser.

Publishing:
This folder must be uploaded to a web hosting service. The domain utkarshverma.com must be registered separately and connected to the hosting provider. Google indexing is a later step and is not guaranteed immediately.

Privacy:
Review every detail before making the site public. Get friends' permission before publishing their names or photos. Do not add a home address, phone number, school timetable, or other private details.
